/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on March 09, 2017, 9:07 AM
 * Purpose:  Calculates a theater’s
gross and net box office profit for a night
 */

//System Libraries Here
#include <iostream>
#include <string>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
const float PERCENT=.20f;

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int pAdult=10, pChild=6,        //Price of Adult and Children tickets
            mAdults, mChild,        //amount of Adult and Children tickets
            adults, child;        
    float grossBO,profBO,dist;
    string movie;
    
    
    //Input or initialize values Here
    cout<<"Enter name of movie = "<<endl;
    getline(cin, movie);
    cout<<"Enter amount of  Adult tickets sold = "<<endl;
    cin>>adults;
    cout<<"Enter amount of Children tickets sold = "<<endl;
    cin>>child;
            
    //Process/Calculations Here
    mAdults=adults*pAdult;           //Money earned from adult tickets
    mChild=child*pChild;             //Money earned from Children tickets
    grossBO=mAdults+mChild ;         //Gross Box office Profit
    profBO=grossBO*PERCENT;          //Net Box office Profit
    dist=grossBO-profBO;             //Paid to Distributor        
    //Output Located Here
    cout<<"Movie Name = "<<movie<<endl;
    cout<<"Adult tickets sold = "<<adults<<endl;
    cout<<"Children tickets sold = "<<child<<endl;
    cout<<"Gross Box Office Profit = "<<grossBO<<endl;
    cout<<"Net Box Office Profit = "<<profBO<<endl;
    cout<<"Amount paid to Distributor = "<<dist<<endl;
           

    //Exit
    return 0;
}

