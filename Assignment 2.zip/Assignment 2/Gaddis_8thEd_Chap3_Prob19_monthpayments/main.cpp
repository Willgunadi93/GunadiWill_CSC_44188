/* 
 * File:   main.cpp
 * Author: William Gunadi
 * Created on February 14, 2017, 11:32 AM
 * Purpose:  Calculate Interest Earned
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>
#include <iomanip>
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
float PERCENT=100.00f;
//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float pricpal,      //Balance in savings account
          rate,          //rate of interest
          temp,
          amnt;         //Amount of money after interest
          
    int compnd;       //Number of times interest is compounded
            
    //Initialize variables
    
    //Input data
    cout<<"Enter amount of principal in savings account = "<<endl;
    cin>>pricpal;
    cout<<"Enter Interest Rate = "<<endl;
    cin>>rate;
    cout<<"Enter times principal is compounded = "<<endl;
    cin>>compnd;
            
    //Map inputs to outputs or process the data
    temp=(1+rate/PERCENT/compnd);        //part of equation
    amnt=pricpal*pow(temp,compnd);  
    float intrst=pow(temp,compnd);
    //Output the transformed data
    cout<<setprecision(2)<<fixed;
    cout<<"Interest rate = "<<rate<<"%"<<endl;
    cout<<"Times Compounded = "<<compnd<<endl;
    cout<<"Principal = $"<<pricpal<<endl;
    cout<<"Interest = $"<<amnt-pricpal<<endl;
    cout<<"Amount in savings = $"<<amnt<<endl;
    //Exit stage right!
    return 0;
}

