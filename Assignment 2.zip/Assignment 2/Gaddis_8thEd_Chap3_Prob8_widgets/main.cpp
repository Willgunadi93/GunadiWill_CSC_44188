/* 
 * File:   main.cpp
 * Author: William Gunadi
 * Created on February 14, 2017, 11:32 AM
 * Purpose:  Template to be utilized in creating
 *           solutions to problems in our CSC/CIS 5 
 *           class.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
     //Declare variables
    float wgtWid=12.5,      //Weight of a single widget
          totPal,wghPal,
          amtWid;    //Total weight of pallet and weight of pallet  
    //Initialize variables
    
    //Input data
    cout<<"What is the weight of pallet"<<endl;
    cin>>wghPal;
    cout<<"Total weight of the pallet"<<endl;
    cin>>totPal;
    //Map inputs to outputs or process the data
    amtWid=totPal-wghPal/wgtWid;
    //Output the transformed data
    cout<<"Amount of Widgets stacked on top of pallet = "<<amtWid<<endl;
    //Exit stage right!
    return 0;
}

