/* 
 * File:   main.cpp
 * Author: William Gunadi
 * Created on February 14, 2017, 11:32 AM
 * Purpose:  Template to be utilized in creating
 *           solutions to problems in our CSC/CIS 5 
 *           class.
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <iomanip>
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const float yenPerD=98.93f;      //yen Per Dollar
const float eurPerD=0.74f;        //euros Per Dollar
//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int money;      //Amount of Dollar
    float dToYen, dToEur;
    //Initialize variables
    
    //Input data
    cout<<"Enter Dollar to yen and euros"<<endl;
    cin>>money;
        
    //Map inputs to outputs or process the data
    
    dToYen=money*yenPerD;       //Converting Dollars to yen
    dToEur=money*eurPerD;       //Converting Dollars to Euros
            
    //Output the transformed data
    cout<<setprecision(2)<<fixed;
    cout<<"Dollars to yen = "<<dToYen<<setw(5)<<endl;
    cout<<"Dollars to Euros = "<<dToEur<<setw(5)<<endl;
    //Exit stage right!
    return 0;
}

