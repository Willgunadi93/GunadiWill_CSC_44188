/* 
 * File:   main.cpp
 * Author: William Gunadi
 * Created on February 14, 2017, 11:32 AM
 * Purpose:  Calculate how much ingredients needed for n number of cookies
 * 
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    unsigned char nCookies=48;
    float sugar=1.5f,
          butter=1.0f,
          flour=2.75f;
    int cookies;     //amount of cookies
    float rate,bSugar,
    bButter,
    bFlour;
    //Initialize variables
    
    //Input data
    cout<<"Enter amount of cookies to make = "<<endl;
    cin>>cookies;
    
    //Map inputs to outputs or process the data
    rate = cookies/nCookies; 
    bSugar=sugar*rate;
    bButter=butter*rate;
    bFlour=flour*rate;        
    //Output the transformed data
    cout<<"Number of cups of Sugar needed = "<<bSugar<<endl;
    cout<<"Number of cups of Butter needed = "<<bButter<<endl;
    cout<<"Number of cups of Flour needed = "<<bFlour<<endl;
    //Exit stage right!
    return 0;
}

