/* 
 * File:   main.cpp
 * Author: William Gunadi
 * Created on February 14, 2017, 11:32 AM
 * Purpose:  Template to be utilized in creating
 *           solutions to problems in our CSC/CIS 5 
 *           class.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int stocks=1000;
    float fStocks=45.50f;
    float fComm=.02;
    
    float sStocks=56.90f;
         
    float totStks,fstComm,sldSto,secComm,totComm,profit;
    
    //Initialize variables
    
    //Input data
    totStks=stocks*fStocks;
    fstComm=totStks*fComm;
    sldSto=stocks*sStocks;
    secComm=sldSto*fComm;
    totComm=fstComm+secComm;
    profit=(totStks-fstComm)-(sldSto-secComm);
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"Amount of money Joe paid for stocks = $"<<totStks<<endl;
    cout<<"Amount of Commission Joe paid for= $"<<fstComm<<endl;;
    cout<<"Amount of money Joe sold the stocks = $"<<sldSto<<endl;
    cout<<"Amount of commission Joe sold the stocks = $"<<secComm<<endl;
    cout<<"Amount of money Joe profited from  stocks = $"<<profit<<endl;
    
    //Exit stage right!
    return 0;
}

