/* 
 * File:   main.cpp
 * Author: William Gunadi
 * Created on February 14, 2017, 11:32 AM
 * Purpose:  Total Calories Consumed eating a bag of cookies.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int Bag=30,        //Cookies in a bag
        totServ=10,       //Total Servings of cookies in a bag           
        CalperS=300,
        cookAte,ckPerSv,Cookie,cPerCk;    //Calories per serving
    //Initialize variables
    
    //Input data
    cout<<"Enter how many cookies consumed"<<endl;
    cin>>cookAte;
    
    //Map inputs to outputs or process the data
    ckPerSv=Bag/totServ;        //Cookies per Serving
    cPerCk=CalperS/ckPerSv;     //Calories per Cookie
    Cookie=cookAte*cPerCk;
    
    //Output the transformed data
    cout<<"Calories consumed = "<<Cookie<<endl;
    //Exit stage right!
    return 0;
}

