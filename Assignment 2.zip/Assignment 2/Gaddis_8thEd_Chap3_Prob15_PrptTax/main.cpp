/* 
 * File:   main.cpp
 * Author: William Gunadi
 * Created on March 07, 2017, 11:32 AM
 * Purpose:  Calculate number of widgets stacked on top of pallet.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const float assmPer = .60f;      //Assesment value percentage of real value
//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    long int  landVal;      //Land Value
    float taxVal, assmVal, propTax=.75;      //Property tax per 100
    //Initialize variables
    
    //Input data
    cout<<"Enter property value"<<endl;
    cin>>landVal;
    //Map inputs to outputs or process the data
    assmVal=landVal*assmPer;
    taxVal=assmVal/100*propTax;
    
    //output Data
    
    cout<<"Assesment value = "<<assmVal<<endl;
    cout<<"Property Tax = "<<taxVal<<endl;
            
    //Exit stage right!
    return 0;
}

